//
//  Header.h
//  Noms
//
//  Created by Nathan Lam on 4/28/15.
//  Copyright (c) 2015 COS333. All rights reserved.
//


#define KEY_CURRENT_NAME @"key_current_name"



